package fr.openium.tinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by t.coulange on 29/01/2018.
 */

public class AdapterSwipeView extends BaseAdapter {
    private List<Person> personList;

    public AdapterSwipeView(List<Person> personList) {
        this.personList = personList;
    }

    @Override
    public int getCount() {
        return personList.size();
    }

    @Override
    public Object getItem(int i) {
        return personList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return personList.get(i).hashCode();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
            view = inflater.inflate(R.layout.item_swipe_view, viewGroup, false);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.textViewName.setText(personList.get(i).name);

        return view;
    }

    static class ViewHolder {
        TextView textViewName;

        ViewHolder(View view) {
            textViewName = view.findViewById(R.id.textView);
        }
    }
}
