package fr.openium.tinder;

/**
 * Created by t.coulange on 29/01/2018.
 */

public class Person {
    public String name;
}
